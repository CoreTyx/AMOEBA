# Pin-level bench for `forte_top`

Post-synthesis verification of the ASIC.  The bench is the bring-up FPGA in
simulation: it drives and observes `forte_top` **through its pads only**, so
the RTL, the synthesized netlist and (later) the placed-and-routed netlist all
run the same bench unchanged.  Nothing here reads a hierarchical signal; the
RTL flow in `sim/` (Spike co-simulation, RVFI) remains the authority on whether
a *program* is correct, and this bench establishes that the *chip* does the same
thing at its pins.

## What the bench does (the FPGA's jobs)

| Job | Where | Notes |
|---|---|---|
| External memory + link protocol | `pin_link_agent.sv` | `hdl/forte_link_pkg.sv` protocol, 256 MiB sparse memory, `tohost` detection, random `ready`/`rvalid` gaps and read latency |
| Console | `pin_uart_agent.sv` | 8N1 at a fixed divisor: one bit = `16 * (div << UART_PRESCALE)` core clocks (32 at div 1) |
| `rst_n`, `irq[1:0]`, `fault_inject`, `test_mode`/`scan_en`, `status` | `pin_tb.sv` | `irq` = PLIC sources 3 and 6; DFT is a stub until the DFT flow lands |
| Command interface | `pin_tb.sv` | the script language below |
| Per-cycle pin trace, pad output windows, `clk_out` | `pin_cycle_trace.sv` | every port every cycle after reset (`pin_cycle.log.gz`); SDC output-delay windows; `clk_out` insertion delay |

**Clocking**, as on the board: `core_clk` (100 MHz) comes from the bench and
`forte_top` ties `link_clk` to it.  Bench outputs launch `FPGA_TCO_PS` (2 ns)
after the `core_clk` posedge; chip outputs are sampled `FPGA_SAMPLE_PS` (5 ns)
after the `clk_out` posedge, so an SDF run's clock insertion delay is tracked
the way the FPGA tracks it.  `+FPGA_SAMPLE_REF=core` samples after the
`core_clk` posedge instead -- the reference the SDC's `set_output_delay` uses;
the post-PnR flow (`postpnr/`) sets every one of these from the PnR SDC.

**4-state.**  Every earlier test ran 2-state.  Here the chip's flops start X,
unwritten memory can read back X (`mem_policy x`), `io_in` can carry X between
read words (`+FPGA_IO_IDLE=x`), and every sampled pin is checked with `$isunknown`.  Verilator
collapses all of that to 2-state: a Verilator pass validates the bench and the
flow, **not** X behaviour.  That is what the VCS runs are for.

## Checks

Link (each is an error, and the first error ends the run by default):
`req`/`wr` never X/Z; `io_out` never X/Z (the chip drives it continuously and
parks it at 0 between transactions); `req` for exactly four cycles (the four
address bytes), never mid-transaction; `wr` held; every address in `EXT_MEM` and
line-aligned; the first transaction after reset is a read of
`0x8000_0000`; a `req` more than 3 cycles after `ready` fell; a transaction
not finished within 1000 link cycles (watchdog).
UART: `uart_tx` never X/Z, framing (stop bit), optional fail patterns.
`status` and `clk_out`: never X/Z once out of reset.

## Running

```bash
# local (Verilator, RTL only)
SIM=verilator DUT=rtl hvl/pin/pin.sh build
SIM=verilator DUT=rtl hvl/pin/pin.sh run testcode/baremetal/sorting_algo.c
SIM=verilator DUT=rtl hvl/pin/pin.sh run hvl/pin/tests/irq.c hvl/pin/tests/irq.cmd
hvl/pin/selftest/run.sh                     # the harness's own tests
hvl/pin/vm_pack.sh                          # one file for the VM: sim/pin/vm_bundle.tgz

# VM (VCS, no git): see docs/postsynth_vm_runbook.md
tar -xzf vm_bundle.tgz; cp hvl/pin/vm_paths.example.sh hvl/pin/vm_paths.sh   # fill in, once
hvl/pin/vm_run.sh                           # paste back sim/pin/vm_results/SUMMARY
```

`DUT` is `rtl` (RTL with `SYNTHESIS` defined, so SRAM macros and pad cells as
synthesized), `rtl_sva` (RTL without it: behavioural arrays and pads, with the
RTL's SVA), or `gate` (netlist, VCS only).  Each run leaves
`sim/pin/runs/<sim>_<dut>/<name>/` with `RESULT`, `sim.log`, `pin_trace.log`
and `uart.log`; `pin.sh compare <runA> <runB>` requires two traces to match
cycle for cycle.

Programs end with `tohost = (code << 1) | 1` **followed by `fence.i`**: the D$ is
write-back, and only `fence.i` (which flushes it, `FenceI -> FlushDCache`) makes
the store visible on the link.  `bin/startup.s` does this for every bare-metal
test; an unexpected trap exits with code `0x400 | mcause`.

## Command scripts

`pin.sh run <program> <script.cmd>`; `$MEM` is the program image, `$RUN` the
run directory, `$REPO` the checkout.  One command per line, `#` comments:

| Command | Effect |
|---|---|
| `mem_policy x\|zero\|rand` | what unwritten memory reads as |
| `load_lst <path>` / `load_bin <path> <hexaddr>` | load memory |
| `reset <cycles>` | hold `rst_n` low, then release |
| `run <cycles>` | wait |
| `run_until_tohost <timeout>` / `run_until_uart <timeout> <text>` | wait for an event; timeout fails |
| `expect_tohost <code>` | exit code must match |
| `uart_div <n>` / `uart_gap <bits>` / `uart_send <text>` / `uart_fail <text>` | console |
| `irq <0\|1> <0\|1>` / `fault_inject <0\|1>` | pins |
| `dump_mem <hexaddr> <nbytes> <path>` | write memory to a file |
| `dft ...` | stub: fails until DFT testing exists |
| `finish` | pass, if no checker has fired |

## Plusargs

`+FPGA_TCO_PS` `+FPGA_SAMPLE_PS` `+FPGA_RD_LAT` `+FPGA_GAP_PCT` `+FPGA_SEED`
`+FPGA_MEM=x|zero|rand` `+FPGA_IO_IDLE=0|x|z` `+FPGA_X_IN_RESET` `+FPGA_WDOG` `+UART_DIV`
`+UART_PRESCALE` `+UART_TX_GAP` `+UART_QUIET` `+MAX_ERRORS` `+TIMEOUT` `+CLK_PS`.
`+FPGA_MUTATE=1..3` breaks the bench on purpose (self-test only).

Timing against an SDC (`postpnr/sdc_delays.py --plusargs max|min` prints them):
`+FPGA_SAMPLE_REF=core|clk_out` (link outputs sampled after `core_clk` or
`clk_out`), `+UART_SAMPLE_PS` (`uart_tx` sampled that long after the posedge
instead of at the negedge), `+PIN_CYCLE_TRACE=<file>` (pin.sh always sets it),
`+PIN_TRACE_SAMPLE_PS` (default 3/4 T), and the pad windows
`+OUT_MAX_LINK_PS` `+OUT_MIN_LINK_PS` (`io_out`, `req`, `wr`) and
`+OUT_MAX_SLOW_PS` `+OUT_MIN_SLOW_PS` (`uart_tx`, `status`) -- off unless given,
and meaningful only with an SDF (in RTL every output moves on the edge).

Every run writes `pin_cycle.log.gz`, the per-cycle pin trace.
`bin/pin_trace_cmp.py <runA> <runB>` compares it, the link trace and the
console, cycle-exact.  A gate build with an SDF fails on any `SDFCOM_*`
message, and a run fails on any VCS `Timing violation` (see `pin.sh`'s header
for `PIN_WAIVERS`, `INITREG` and the `PIN_*` overrides).

Waveforms (VCS): `WAVES=1` on both the build and the run (it selects a separate
build directory, `<sim>_<dut>_waves`), plus `+PIN_VCD` (and `+PIN_VCD_CYCLES=n`,
default 400, 0 = whole run) on the run; `pin.vcd` lands in the run directory.
`bin/vcd_first_x.py pin.vcd --after <ns>` lists the first signals to go X.
For Verdi, `+PIN_FSDB` instead (VCS only) writes the whole run to `wave.fsdb`;
open it with `verdi -ssf <run dir>/wave.fsdb`.

    WAVES=1 SIM=vcs DUT=rtl_sva hvl/pin/pin.sh build
    WAVES=1 SIM=vcs DUT=rtl_sva TAG=w hvl/pin/pin.sh run sim/pin/images/uart_echo.lst \
        sim/pin/images/uart_echo.cmd +PIN_VCD +PIN_VCD_CYCLES=5600

`selftest/sram_cmp.sh` compares each PDK `rf_sp_*` model in `SRAM_MODELS` with
the RTL's behavioural RAM under random traffic (part of the VCS self-test).  A
difference is SRAM behaviour the caches were never verified against.
