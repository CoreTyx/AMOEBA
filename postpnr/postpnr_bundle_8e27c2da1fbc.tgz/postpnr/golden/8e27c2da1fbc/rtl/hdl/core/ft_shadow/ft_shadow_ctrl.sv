///////////////////////////////////////////
// ft_shadow_ctrl.sv
//
// Written: Siddharth Rau (sidrau2@illinois.edu)
//
// Purpose: Shared mismatch retry, diagnosis, and replica-selection controller.
//
// Usage:
// Instantiated independently for the ALU and comparison lanes in ft_alu,
// and for retry-only multiplier recovery in ft_mul. TE_THRESHOLD must be
// positive; advance acknowledges acceptance by the owning pipeline stage.
//
// Functionality:
// Captures the first mismatch, counts consecutive mismatches, and requests
// stalls during retry or supported recomputation. A uniquely passing
// diagnostic relation isolates the failing replica; ambiguous or unsupported
// diagnosis reports unresolved until acceptance. Isolation persists until
// reset/flush; the owning core records reset-sticky diagnostic status.
//
// check marks the cycles in which mismatch and the recompute results are to
// be acted on. A wrapper that compares combinationally ties it high and gets
// one evaluation per clock. ft_alu compares registered copies of its channels
// and pulses check once per evaluation; between pulses the controller holds
// its state, and stall_req means "the evaluation in progress did not produce
// a trusted result" rather than a stall to apply directly.
///////////////////////////////////////////

module ft_shadow_ctrl #(
  // Number of consecutive mismatches before escalation; must be >= 1.
  parameter int TE_THRESHOLD = 3
) (
  // Clock/reset/flush define the lifetime of the held transaction.
  input  logic clk, reset, flush,
  input  logic valid,                 // operation currently occupies the wrapper
  input  logic check,                 // mismatch and the recompute results are valid this cycle: evaluate them
  input  logic advance,               // owning pipeline stage accepts the transaction
  input  logic mismatch,              // primary and shadow outputs disagree
  input  logic recompute_supported,   // wrapper supplies a trusted alternate test
  input  logic recompute_primary_ok,  // primary passes the alternate test
  input  logic recompute_shadow_ok,   // shadow passes the alternate test
  output logic recompute_mode,        // alternate test is active
  output logic capture_normal,        // snapshot the first mismatch at this edge
  output logic stall_req,             // hold all architectural stages
  output logic unresolved,            // no trustworthy result; take a trap
  output logic isolated,              // one copy has been diagnosed
  output logic use_shadow,            // select shadow after primary failure
  output logic pe_primary,
  output logic pe_shadow              // diagnostic isolation indicators
);

  // Keep one counter bit for the threshold-one configuration.
  localparam int COUNT_W = (TE_THRESHOLD == 1) ? 1 : $clog2(TE_THRESHOLD);
  localparam logic [COUNT_W-1:0] RETRY_LIMIT = COUNT_W'(TE_THRESHOLD-1);
  // UNRESOLVED releases the instruction so Wally can report a precise
  // exception; all earlier states preserve the original transaction.
  typedef enum logic [2:0] {NORMAL, RETRY, RECOMPUTE, ISOLATED, UNRESOLVED} state_t;
  state_t state;
  logic [COUNT_W-1:0] mismatch_count;

  assign recompute_mode = (state == RECOMPUTE);
  // Capture unmasked post-injection results once, including threshold 1.
  assign capture_normal = (state == NORMAL) & check & valid & mismatch & ~reset & ~flush;
  assign isolated       = (state == ISOLATED);
  assign unresolved     = (state == UNRESOLVED);
  // A mismatch/recompute holds every architectural stage.  UNRESOLVED is
  // deliberately not stalled so the owning stage can advance and report a
  // precise synchronous trap. Other stall sources may delay that acceptance.
  assign stall_req      = (state == RECOMPUTE) |
                          (((state == NORMAL) | (state == RETRY)) & valid & mismatch);

  // State is synchronous; datapath results remain combinational for retries.
  always_ff @(posedge clk) begin
    if (reset | flush) begin
      state          <= NORMAL;
      mismatch_count <= '0;
      use_shadow     <= 1'b0;
      pe_primary     <= 1'b0;
      pe_shadow      <= 1'b0;
    end else begin
      case (state)
        // First disagreement starts the retry count; normal execution has
        // no added latency when both copies agree.
        NORMAL: if (check) begin
          mismatch_count <= '0;
          if (valid & mismatch) begin
            mismatch_count <= COUNT_W'(1);
            if (TE_THRESHOLD == 1) begin
              if (recompute_supported) state <= RECOMPUTE;
              else                     state <= UNRESOLVED;
            end else state <= RETRY;
          end
        end
        // The pipeline remains frozen while the same operation is observed
        // again. A matching retry returns directly to NORMAL.
        // Threshold one bypasses RETRY; its zero retry limit is intentional.
        /* verilator lint_off UNSIGNED */
        RETRY: if (check) begin
          if (!valid | !mismatch) begin
            state          <= NORMAL;
            mismatch_count <= '0;
          end else if (mismatch_count >= RETRY_LIMIT) begin
            if (recompute_supported) state <= RECOMPUTE;
            else                     state <= UNRESOLVED;
          end else begin
            mismatch_count <= mismatch_count + COUNT_W'(1);
          end
        end
        /* verilator lint_on UNSIGNED */
        // Recompute is one diagnostic cycle. Exactly one passing relation is
        // required; agreement or disagreement by both copies is ambiguous.
        RECOMPUTE: if (check) begin
          // A copy is bad when its alternate result no longer has the known
          // relationship to its own saved normal result.
          if (recompute_primary_ok & ~recompute_shadow_ok) begin
            pe_shadow <= 1'b1;
            use_shadow <= 1'b0;
            state <= ISOLATED;
          end else if (~recompute_primary_ok & recompute_shadow_ok) begin
            pe_primary <= 1'b1;
            use_shadow <= 1'b1;
            state <= ISOLATED;
          end else begin
            state <= UNRESOLVED;
          end
        end
        // The diagnosed-good copy is used for subsequent operations until a
        // flush/reset; the bad copy is never trusted again in this instance.
        ISOLATED: state <= ISOLATED;
        // Keep the fault and masked result until the pipeline accepts it.
        UNRESOLVED: begin
          if (advance) begin
            state          <= NORMAL;
            mismatch_count <= '0;
          end
        end
        default: state <= NORMAL;
      endcase
    end
  end
endmodule
