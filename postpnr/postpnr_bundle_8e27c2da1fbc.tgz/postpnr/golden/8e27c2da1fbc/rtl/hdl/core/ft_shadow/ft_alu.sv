///////////////////////////////////////////
// ft_alu.sv
//
// Written: Siddharth Rau (sidrau2@illinois.edu)
//
// Purpose: E-stage ALU/address and architectural comparison protection.
//
// Usage:
// Instantiated by the IEU datapath with muxed ALU operands and separate
// forwarded comparison operands. Returns ALUResult, Sum, and {eq, lt} flags.
//
// Functionality:
// Duplicates both lanes with independent recovery controllers and replica
// selection. Retries mismatches, uses supported arithmetic/shift relations
// for diagnosis, and isolates a uniquely identified failing replica. Holds
// or masks public results during recovery/unresolved faults; private widened
// results and first-mismatch snapshots terminate inside this wrapper.
//
// Timing: an evaluation takes three cycles, and nothing in it crosses from
// the ALU to the rest of the core inside one cycle.
//   COMPUTE  both replicas run; their channels are captured into registers.
//   COMPARE  the registered channels are compared and the controllers act.
//   DONE     the registered result of the selected replica is presented and
//            the stall released.  A failed evaluation returns to COMPUTE.
// stall_req is high from the cycle an instruction arrives until DONE, and
// comes from the phase register alone, so the hazard unit sees it early.
// The results are registers too, so the paths out of Execute (the next
// pipeline register, the data cache address, the branch decision) start
// here and not at the operands.  Every valid instruction therefore spends
// at least three cycles in Execute; the pipeline is held while it does, and
// an instruction fetch takes longer than that, so the cycles overlap.
///////////////////////////////////////////

module ft_alu import cvw::*; #(
  parameter cvw_t P,
  parameter int TE_THRESHOLD = 3
) (
  input  logic              clk, reset, flush, valid, advance,
  input  logic              load,                     // Execute takes its next instruction at this clock edge
  input  logic              hold,                     // the operands cannot be used this cycle: do not capture from them
  input  logic [P.XLEN-1:0] A, B,
  // Branches need PC+immediate and register comparison simultaneously.
  input  logic [P.XLEN-1:0] cmp_a, cmp_b,
  input  logic              cmp_sgnd,
  input  logic              W64, UW64, SubArith,
  input  logic [2:0]        ALUSelect,
  input  logic [3:0]        BSelect, ZBBSelect,
  input  logic [2:0]        Funct3, BALUControl,
  input  logic [6:0]        Funct7,
  input  logic [4:0]        Rs2E,
  input  logic              BMUActive,
  input  logic [1:0]        CZero,
  // Shared runtime enable; each replica/channel selects faults locally.
  input  logic              fi_enable, cmp_fi_enable, // ALU and comparison injection are independently enabled
  input  logic [15:0]       fi_lfsr,                  // shared fault-injection generator (ft_fault_gen)
  input  logic [FI_COUNT_BITS-1:0] fi_count,
  output logic [P.XLEN-1:0] ALUResult, Sum,
  output logic [1:0]        flags,  // unchanged comparator schema: {eq, lt}
  output logic              stall_req, unresolved, pe_primary, pe_shadow,
  output logic              cmp_pe_primary, cmp_pe_shadow,
  output logic [1:0]        fault_detect, fault_unresolved  // {CMP, ALU}: mismatch found by a check; lane unresolved
);
  logic [P.XLEN-1:0] result_raw[2], result_pre_fi[2], result_live[2];
  logic [P.XLEN:0] arith_raw[2], arith_live[2], cmp_raw[2], cmp_live[2];
  logic [P.XLEN+1:0] shift_raw[2], shift_live[2];
  // The channels as captured in COMPUTE.  Everything downstream -- the compare,
  // the diagnosis, the snapshots and the outputs -- reads these.
  logic [P.XLEN-1:0] result_q[2];
  logic [P.XLEN:0] arith_q[2], cmp_q[2];
  logic [P.XLEN+1:0] shift_q[2];
  typedef enum logic [1:0] {COMPUTE, COMPARE, DONE} phase_t;
  phase_t phase;
  logic check, retry, accepted;
  logic [P.XLEN-1:0] normal_result[2];
  logic [P.XLEN:0] normal_arith[2], normal_cmp[2];
  logic [P.XLEN+1:0] normal_shift[2];
  logic [P.XLEN:0] cmp_extended_a, cmp_extended_b;
  logic alu_mismatch, cmp_mismatch, arithmetic_operation, slt_operation, shift_operation;
  logic alu_recompute, cmp_recompute, arith_recompute, shift_recompute;
  logic alu_capture_normal, cmp_capture_normal, alu_isolated, cmp_isolated;
  logic alu_use_shadow, cmp_use_shadow, alu_stall, cmp_stall, alu_unresolved, cmp_unresolved;
  logic alu_supported, alu_ok[2], cmp_ok[2];

  // Do not use BMUActive to exclude shifts: the existing BMU decoder also
  // recognizes ordinary shifts. Rotates keep their original n-bit ring.
  assign slt_operation = ~W64 & ~BMUActive &
                         ((ALUSelect == 3'b010) | (ALUSelect == 3'b011));
  assign arithmetic_operation = (~W64 & ~BMUActive & (ALUSelect == 3'b000)) | slt_operation;
  assign shift_operation = ~BALUControl[2] &
      ((ALUSelect == 3'b001) | ((ALUSelect == 3'b101) & ~P.ZBS_SUPPORTED)) &
      ((BSelect == 4'b0000) | ((BSelect == 4'b0001) & UW64));
  // A shift relation gives no evidence about a faulty independent address
  // channel. Such disagreement must trap, even if the shift itself is healthy.
  assign alu_supported = arithmetic_operation | (shift_operation & (arith_q[0] == arith_q[1]));
  assign arith_recompute = alu_recompute & arithmetic_operation;
  assign shift_recompute = alu_recompute & shift_operation;
  assign cmp_extended_a = {cmp_sgnd & cmp_a[P.XLEN-1], cmp_a};
  assign cmp_extended_b = {cmp_sgnd & cmp_b[P.XLEN-1], cmp_b};

  // w64 is an argument rather than a read of the module's W64: VCS -xprop cannot
  // instrument a block that calls a function reading a signal outside its arguments.
  function automatic logic [P.XLEN-1:0] shift_result(
    input  logic [P.XLEN+1:0] wide, input logic diagnostic, input logic w64);
    logic [P.XLEN-1:0] aligned;
    aligned = diagnostic ? wide[P.XLEN+1:2] : wide[P.XLEN-1:0];
    if ((P.XLEN == 64) && w64)
      shift_result = {{(P.XLEN-32){aligned[31]}}, aligned[31:0]};
    else shift_result = aligned;
  endfunction

  for (genvar i = 0; i < 2; i++) begin : replica
    // Sum is taken from the injected wide arithmetic channel, not this pin.
    /* verilator lint_off PINCONNECTEMPTY */
    alu #(P) compute(.A, .B, .W64, .UW64, .SubArith, .ALUSelect,
      .BSelect, .ZBBSelect, .Funct3, .Funct7, .Rs2E, .BALUControl, .BMUActive, .CZero,
      .RecomputeArith(arith_recompute), .RecomputeShift(shift_recompute),
      .ArithWide(arith_raw[i]), .ShiftWide(shift_raw[i]),
      .ALUResult(result_raw[i]), .Sum());
    /* verilator lint_on PINCONNECTEMPTY */
    addsub #(.WIDTH(P.XLEN+1)) compare(
      .a(cmp_extended_a), .b(cmp_extended_b), .sub(1'b1),
      .recompute(cmp_recompute), .result(cmp_raw[i]));

    // Each physical result channel has its own event phase on the shared generator,
    // 16 cycles apart, so no two channels (and no replica and its shadow) fault together.
    ft_fault_inject #(.WIDTH(P.XLEN), .PHASE(9'h1FE - 9'(i*64))) result_fi(
      .reset, .lfsr(fi_lfsr), .count(fi_count), .fi_enable, .data_i(result_pre_fi[i]), .data_o(result_live[i]));
    ft_fault_inject #(.WIDTH(P.XLEN+1), .PHASE(9'h1EE - 9'(i*64))) arith_fi(
      .reset, .lfsr(fi_lfsr), .count(fi_count), .fi_enable, .data_i(arith_raw[i]), .data_o(arith_live[i]));
    ft_fault_inject #(.WIDTH(P.XLEN+2), .PHASE(9'h1DE - 9'(i*64))) shift_fi(
      .reset, .lfsr(fi_lfsr), .count(fi_count), .fi_enable, .data_i(shift_raw[i]), .data_o(shift_live[i]));
    ft_fault_inject #(.WIDTH(P.XLEN+1), .PHASE(9'h1CE - 9'(i*64))) cmp_fi(
      .reset, .lfsr(fi_lfsr), .count(fi_count), .fi_enable(cmp_fi_enable), .data_i(cmp_raw[i]), .data_o(cmp_live[i]));

    // A shift-channel fault must reach the architectural output, including
    // word sign extension. The injection bit stays physical during diagnosis.
    assign result_pre_fi[i] = shift_operation ? shift_result(shift_live[i], shift_recompute, W64) : result_raw[i];
    // No reset: nothing reads these before a COMPUTE cycle has written them.
    always_ff @(posedge clk)
      if (phase == COMPUTE) begin
        result_q[i] <= result_live[i];
        arith_q[i]  <= arith_live[i];
        shift_q[i]  <= shift_live[i];
        cmp_q[i]    <= cmp_live[i];
      end
    assign cmp_ok[i] = (cmp_q[i] == ~normal_cmp[i]);
    always_comb begin
      alu_ok[i] = 1'b0;
      if (arithmetic_operation) begin
        alu_ok[i] = (arith_q[i] == ~normal_arith[i]);
        if (slt_operation) begin
          alu_ok[i] &= (normal_result[i] == {{(P.XLEN-1){1'b0}}, normal_arith[i][P.XLEN]}) &
                       (result_q[i] == {{(P.XLEN-1){1'b0}}, arith_q[i][P.XLEN]});
        end else alu_ok[i] &= (result_q[i] == ~normal_result[i]);
      end else if (shift_operation) begin
        alu_ok[i] = (shift_result(normal_shift[i], 1'b0, W64) == shift_result(shift_q[i], 1'b1, W64)) &
                    (normal_result[i] == shift_result(normal_shift[i], 1'b0, W64)) &
                    (result_q[i] == shift_result(shift_q[i], 1'b1, W64)) &
                    (arith_q[i] == normal_arith[i]) & (arith_q[0] == arith_q[1]);
      end
    end
    always_ff @(posedge clk) begin
      if (reset | flush) begin
        normal_result[i] <= '0;
        normal_arith[i] <= '0;
        normal_shift[i] <= '0;
        normal_cmp[i] <= '0;
      end else begin
        if (alu_capture_normal) begin
          normal_result[i] <= result_q[i];
          normal_arith[i] <= arith_q[i];
          normal_shift[i] <= shift_q[i];
        end
        if (cmp_capture_normal) normal_cmp[i] <= cmp_q[i];
      end
    end
  end

  // One evaluation: COMPUTE, COMPARE, then DONE if both controllers accept the
  // result or back to COMPUTE if either wants it run again (a retry, or the
  // pass after a diagnosis).  A new instruction, or a flush, starts over.  A
  // COMPUTE cycle whose operands are held back is simply repeated.
  assign check = (phase == COMPARE);
  assign retry = alu_stall | cmp_stall;
  // The pipeline can only accept what has been presented.
  assign accepted = advance & (phase == DONE);
  always_ff @(posedge clk)
    if (reset | flush | load) phase <= COMPUTE;
    else case (phase)
      COMPUTE: if (~hold) phase <= COMPARE;
      COMPARE: phase <= retry ? COMPUTE : DONE;
      DONE:    phase <= DONE;
      default: phase <= COMPUTE;
    endcase

  assign alu_mismatch = valid & ~alu_recompute & ~alu_isolated &
                       ((result_q[0] != result_q[1]) | (arith_q[0] != arith_q[1]));
  assign cmp_mismatch = valid & ~cmp_recompute & ~cmp_isolated & (cmp_q[0] != cmp_q[1]);
  ft_shadow_ctrl #(.TE_THRESHOLD(TE_THRESHOLD)) alu_ctrl(
    .clk, .reset, .flush, .valid, .check, .advance(accepted), .mismatch(alu_mismatch), .recompute_supported(alu_supported),
    .recompute_primary_ok(alu_ok[0]), .recompute_shadow_ok(alu_ok[1]),
    .recompute_mode(alu_recompute), .capture_normal(alu_capture_normal),
    .stall_req(alu_stall), .unresolved(alu_unresolved), .isolated(alu_isolated),
    .use_shadow(alu_use_shadow), .pe_primary, .pe_shadow);
  ft_shadow_ctrl #(.TE_THRESHOLD(TE_THRESHOLD)) cmp_ctrl(
    .clk, .reset, .flush, .valid, .check, .advance(accepted), .mismatch(cmp_mismatch), .recompute_supported(1'b1),
    .recompute_primary_ok(cmp_ok[0]), .recompute_shadow_ok(cmp_ok[1]),
    .recompute_mode(cmp_recompute), .capture_normal(cmp_capture_normal),
    .stall_req(cmp_stall), .unresolved(cmp_unresolved), .isolated(cmp_isolated),
    .use_shadow(cmp_use_shadow), .pe_primary(cmp_pe_primary), .pe_shadow(cmp_pe_shadow));

  // The pipeline waits for a valid instruction's evaluation to finish.
  assign stall_req = valid & (phase != DONE);
  assign unresolved = alu_unresolved | cmp_unresolved;
  assign fault_detect     = {2{check}} & {cmp_mismatch, alu_mismatch};
  assign fault_unresolved = {cmp_unresolved, alu_unresolved};
  // Outputs read as zero until the evaluation is DONE, and stay zero if it ended
  // unresolved; otherwise they are the registered channels of the selected
  // replica.  Both conditions are register outputs.
  always_comb begin
    ALUResult = result_q[alu_use_shadow];
    Sum = arith_q[alu_use_shadow][P.XLEN-1:0];
    flags = {cmp_q[cmp_use_shadow] == '0, cmp_q[cmp_use_shadow][P.XLEN]};
    if ((phase != DONE) | unresolved) begin
      ALUResult = '0;
      Sum = '0;
      flags = '0;
    end
  end
endmodule
