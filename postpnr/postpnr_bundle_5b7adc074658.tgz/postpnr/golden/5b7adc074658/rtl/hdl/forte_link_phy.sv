///////////////////////////////////////////////////////////////////////////////
// forte_link_phy.sv
//
// The link domain: flits in, pins out.  This is hdl/forte_link_master.sv with
// its AHB face replaced by a FIFO face -- the LM_* FSM, the word accounting and
// the negedge inbound capture are the same logic, because none of it was ever
// AHB-specific.
//
//   LM_START     wait for ready (see "ready" in hdl/forte_link_pkg.sv: a hint
//                with a guard band, not a handshake)
//   LM_HDR       req=1 for ADDR_WORDS cycles, io_o = A[31:24] .. A[7:0]
//   LM_WDATA     WORDS bytes on io_o, LSB first, back to back; a new data flit
//                is popped every WORDS_PER_BEAT-th byte
//   LM_RD_DATA   collect rvalid bytes from io_i; push a beat every
//                WORDS_PER_BEAT-th
//
// io_o and io_i are separate pads, so nothing here ever turns a bus around:
// there is no dir, no output enable and no TA state.  A read goes straight from
// the last header byte to collecting data, and the next transaction may start
// the cycle after the last read byte.
//
// THE BUFFERING INVARIANT.  hdl/forte_link_pkg.sv and top_level_plan.md s4:
// "there is no mid-transaction handshake in either direction, so the ASIC never
// stalls once started".  The FPGA cannot absorb an underrun -- there is no pin
// for it.  So this module must not begin a transaction until the WHOLE thing is
// in the outbound FIFO: ocmd_depth >= BEATS+1 for a write (1 command + BEATS
// beats), >= 1 for a read.  That is why the FIFO's occupancy output is
// load-bearing rather than decorative.
//
// BEATS is a per-build parameter, not 8 -- see "ONE BURST LENGTH PER BUILD" in
// hdl/forte_link_pkg.sv.  Nothing in this module needs to know WHY the count is
// what it is; it only has to agree with forte_link_core and the slave, and
// forte_chip drives all three from one expression.
//
// The abort rule does NOT live here.  Once a command is popped this module
// always finishes it on the wire; whether the AHB master is still interested is
// forte_link_core's problem, which is where HTRANS is visible.
//
// Inbound pins are captured on the falling edge and re-registered on the rising
// edge (docs/top_level_plan.md s6).  With the link domain's own small clock tree
// the hold margin no longer depends on the core tree's insertion delay
// (docs/impl_plan_link_clocking.md s4), but the two stages stay: the second one
// is the retiming this FSM reads.
///////////////////////////////////////////////////////////////////////////////

module forte_link_phy import forte_link_pkg::*; #(
  // Beats per transaction; set by hdl/forte_chip.sv from the core config.  The
  // default matches a 512-bit line and exists only because SystemVerilog needs
  // one -- forte_chip always overrides it.
  parameter BEATS = 8
)(
  input  logic               link_clk,
  input  logic               link_rst_n,

  // outbound flits, read side of the core->link FIFO
  input  logic               ocmd_valid,
  output logic               ocmd_ready,
  input  logic [64:0]        ocmd_data,     // {is_cmd, payload}
  // Occupancy of the outbound FIFO, widened by forte_chip to one fixed width so
  // this module does not have to know how deep that FIFO happens to be.
  input  logic [DEPTH_W-1:0] ocmd_depth,

  // inbound beats, write side of the link->core FIFO
  output logic               ibeat_valid,
  input  logic               ibeat_ready,
  output logic [63:0]        ibeat_data,

  // link pins: io_o to the io_out pads, io_i from the io_in pads
  output logic [LINK_W-1:0]  io_o,
  input  logic [LINK_W-1:0]  io_i,
  output logic               req,
  output logic               wr,
  input  logic               ready,
  input  logic               rvalid,

  output logic               txn_done,     // one-cycle pulse per completed transaction
  // High whenever a transaction is on the wire.  Only consumer is the status
  // pin, which needs to tell "nothing is happening" from "something started and
  // never finished" -- the two look identical from txn_done alone.
  output logic               busy,
  // DFT hold, synchronised into link_clk (hdl/forte_chip.sv, "DFT HOLD").  The
  // tester only holds the chip while the link is quiet; as a guard, ready and
  // rvalid read as 0 while it is set, so the phy cannot start a transaction or
  // take io_i -- which carries scan data during a hold -- and req/wr stay low.
  input  logic               hold
);

  // Words on the wire per transaction, and the widths needed to index them.
  // BEATS >= 2 (checked in forte_link_core), so WORDS >= 16 and WCNT_W >= 4.
  localparam WORDS  = BEATS * WORDS_PER_BEAT;
  localparam WCNT_W = $clog2(WORDS);
  localparam SUB_W  = $clog2(WORDS_PER_BEAT);      // word within a beat
  localparam HCNT_W = $clog2(ADDR_WORDS);          // header word

  // ---- inbound capture: negedge, then posedge ------------------------------
  logic [LINK_W-1:0] io_n, io_s;
  logic              ready_n, ready_s, rvalid_n, rvalid_s;
  always_ff @(negedge link_clk) {io_n, ready_n, rvalid_n} <= {io_i, ready, rvalid};
  always_ff @(posedge link_clk) {io_s, ready_s, rvalid_s} <= {io_n, ready_n & ~hold, rvalid_n & ~hold};

  // ---- state ----------------------------------------------------------------
  link_st_t st;                        // states in hdl/forte_link_pkg.sv

  logic [31:0]       addr_r;
  logic              wr_r;
  logic [63:0]       wdat_r;           // the write beat being serialized
  logic [WCNT_W-1:0] wcnt;             // word within the transaction
  logic [HCNT_W-1:0] hcnt;             // header word on the pins this cycle
  logic [63-LINK_W:0] beat_r;          // all but the last word of the beat being assembled

  logic [SUB_W-1:0]  sub;
  logic              last_word, beat_end, last_hdr;
  logic [HCNT_W-1:0] hnext, hsel;

  assign sub       = wcnt[SUB_W-1:0];
  assign beat_end  = (sub == SUB_W'(WORDS_PER_BEAT - 1));
  assign last_word = (wcnt == WCNT_W'(WORDS - 1));
  assign last_hdr  = (hcnt == HCNT_W'(ADDR_WORDS - 1));
  assign hnext     = hcnt + 1'b1;
  // Header words go out MSB first, so word hnext is the hsel-th from the bottom.
  assign hsel      = HCNT_W'(ADDR_WORDS - 1) - hnext;

  // A command may be taken only when the whole transaction is buffered.
  logic cmd_is_wr, cmd_present, cmd_complete;
  assign cmd_is_wr    = ocmd_data[63];
  assign cmd_present  = ocmd_valid & ocmd_data[64];                 // is_cmd
  assign cmd_complete = cmd_present & (cmd_is_wr ? (ocmd_depth >= DEPTH_W'(BEATS + 1)) : 1'b1);

  // The FIFO is popped for the command, then once per write beat.  The first
  // beat is pulled on the first header cycle, so wdat_r holds it by the last
  // one, which registers word 0; after that the next beat is pulled on the last
  // word of each beat so wdat_r holds it by the cycle its word 0 is registered
  // -- the same one-ahead discipline the old HREADYOUT pulse gave this FSM.
  assign ocmd_ready = ((st == LM_IDLE)  & cmd_complete)
                    | ((st == LM_HDR)   & wr_r & (hcnt == '0))
                    | ((st == LM_WDATA) & beat_end & ~last_word);

  // A read beat is pushed on every WORDS_PER_BEAT-th rvalid word.
  assign ibeat_valid = (st == LM_RD_DATA) & rvalid_s & beat_end;
  assign ibeat_data  = {io_s, beat_r};

  assign busy = (st != LM_IDLE);

  assign txn_done = (st == LM_WDATA & last_word)
                  | (st == LM_RD_DATA & rvalid_s & last_word);

  // Asynchronous reset, unlike the synchronous HRESETn style this FSM inherited
  // from forte_link_master.  Two reasons: everything else in the link domain
  // (both FIFO ports, the status heartbeat) takes link_rst_n asynchronously, and
  // mixing the two on one net is a real design smell -- Verilator flags it as
  // SYNCASYNCNET.  More importantly this module drives pads: an async assert
  // parks the outputs (io_o=0, req=0, wr=0) the instant reset is asserted
  // rather than waiting for an edge, which is what a pad-facing module should do.
  always_ff @(posedge link_clk or negedge link_rst_n) begin
    if (!link_rst_n) begin
      st <= LM_IDLE; io_o <= '0; req <= 1'b0; wr <= 1'b0;
      addr_r <= '0; wr_r <= 1'b0; wdat_r <= '0;
      wcnt <= '0; hcnt <= '0; beat_r <= '0;
    end else begin
      case (st)
        LM_IDLE: begin
          req <= 1'b0; wr <= 1'b0; io_o <= '0;
          if (cmd_complete) begin
            addr_r <= ocmd_data[31:0];
            wr_r   <= cmd_is_wr;
            st     <= LM_START;
          end
        end

        LM_START: begin
          if (ready_s) begin
            io_o <= addr_r[31 -: LINK_W]; req <= 1'b1; wr <= wr_r;
            hcnt <= '0;
            st <= LM_HDR;
          end
        end

        // io_o shows header word hcnt this cycle; register the next one, or on
        // the last header word, whatever follows the header.
        LM_HDR: begin
          hcnt <= hnext;
          if (!last_hdr) begin
            io_o <= addr_r[LINK_W * hsel +: LINK_W];
          end else begin
            req <= 1'b0;
            if (wr_r) begin
              io_o <= wdat_r[LINK_W-1:0]; wcnt <= WCNT_W'(1);   // word 0 is on the pins next cycle
              st <= LM_WDATA;
            end else begin
              io_o <= '0; wcnt <= '0;
              st <= LM_RD_DATA;
            end
          end
        end

        LM_WDATA: begin
          // io_o shows word wcnt-1 this cycle; register word wcnt for the next.
          io_o <= wdat_r[LINK_W * sub +: LINK_W];
          if (last_word) st <= LM_IDLE;
          else           wcnt <= wcnt + WCNT_W'(1);
        end

        LM_RD_DATA: begin
          if (rvalid_s) begin
            // The last word of a beat goes straight out with ibeat_data.
            if (!beat_end) beat_r[LINK_W * sub +: LINK_W] <= io_s;
            wcnt <= wcnt + WCNT_W'(1);
            if (last_word) st <= LM_IDLE;
          end
        end

        default: st <= LM_IDLE;
      endcase

      // The popped write beat lands here.  Not in the case above: the pop is
      // driven combinationally from ocmd_ready, which spans three states.
      if (ocmd_ready & ocmd_valid & ~ocmd_data[64]) wdat_r <= ocmd_data[63:0];
    end
  end

`ifndef SYNTHESIS
  // Assertions are gated on `armed`, not on link_rst_n directly.  Reading the
  // reset as a qualifier inside a clocked block makes Verilator see it as a
  // SYNCHRONOUS reset, which collides with the asynchronous use everywhere else
  // in this domain (both FIFO ports, the status heartbeat) -- SYNCASYNCNET, and
  // a legitimate complaint about one net serving two reset styles.  `armed` also
  // means "at least one clock past reset release", which is what these checks
  // want anyway: none of them is meaningful on the first cycle out of reset.
  logic armed;
  always_ff @(posedge link_clk or negedge link_rst_n)
    if (!link_rst_n) armed <= 1'b0; else armed <= 1'b1;

  // Exactly BEATS beats must leave for every read.  Fewer and the core waits for
  // one that never comes; more and the surplus poisons the next transaction.
  localparam PC_W = $clog2(BEATS + 1);
  logic [PC_W-1:0] push_cnt;
  always_ff @(posedge link_clk or negedge link_rst_n)
    if (!link_rst_n)                        push_cnt <= '0;
    else if (st == LM_IDLE)                 push_cnt <= '0;
    else if (ibeat_valid & ibeat_ready)     push_cnt <= push_cnt + PC_W'(1);
  // Checked on the last read word, whose beat is being pushed in that cycle.
  always @(posedge link_clk)
    if (armed & st == LM_RD_DATA & rvalid_s & last_word)
      assert (ibeat_valid & (push_cnt == PC_W'(BEATS - 1)))
        else $fatal(1, "link phy: pushed %0d beats for a read, not %0d", push_cnt + 1, BEATS);

  // The FPGA cannot absorb an underrun, so a transaction must never start
  // without its whole payload buffered.
  always @(posedge link_clk) if (armed & st == LM_IDLE & cmd_complete & cmd_is_wr)
    assert (ocmd_depth >= DEPTH_W'(BEATS + 1))
      else $fatal(1, "link phy: write started with only %0d of %0d flits buffered", ocmd_depth, BEATS + 1);
  // A data flit where a command was expected, or the reverse, means the two
  // sides have lost sync -- what the is_cmd tag is for.
  always @(posedge link_clk) if (armed & st == LM_IDLE & ocmd_valid & ~ocmd_data[64])
    $fatal(1, "link phy: data flit at the head of the outbound FIFO while idle");
  always @(posedge link_clk) if (armed & st == LM_WDATA & ocmd_ready & ocmd_valid & ocmd_data[64])
    $fatal(1, "link phy: command flit where a write beat was expected");
  // Every write-beat pop must find a beat.  ocmd_ready is not qualified by
  // ocmd_valid, and wdat_r loads only on a valid pop, so a pop that found the
  // FIFO empty would leave the previous beat in wdat_r and put it on the wire
  // with nothing to say so.  The whole-transaction-buffered rule above is what
  // makes this impossible; this is the check that it holds, through the CDC.
  // Written as if/$fatal, not `assert`, so it fires even in a Verilator build
  // made without --assert (sim/Makefile COMMON_FLAGS and hvl/pin/pin.sh do pass it).
  always @(posedge link_clk) if (armed & ocmd_ready & st != LM_IDLE & ~(ocmd_valid & ~ocmd_data[64]))
    $fatal(1, "link phy: write-beat pop in state %0d found valid=%b is_cmd=%b",
           st, ocmd_valid, ocmd_data[64]);
  // The inbound FIFO is sized to BEATS+2 against at most BEATS beats in flight
  // with the core draining, so it can never refuse a push.  If it ever does, a
  // beat is lost.
  always @(posedge link_clk) if (armed & ibeat_valid)
    assert (ibeat_ready) else $fatal(1, "link phy: inbound FIFO full -- read beat dropped");
`endif

endmodule
