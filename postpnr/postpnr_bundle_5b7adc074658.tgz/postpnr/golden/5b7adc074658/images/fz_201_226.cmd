# Cascade program fz_201_226: 852 instructions; descriptor in fz_201_226.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 340800
expect_tohost 0
finish
