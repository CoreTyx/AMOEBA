# Cascade program fz_201_158: 1170 instructions; descriptor in fz_201_158.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 468000
expect_tohost 0
finish
