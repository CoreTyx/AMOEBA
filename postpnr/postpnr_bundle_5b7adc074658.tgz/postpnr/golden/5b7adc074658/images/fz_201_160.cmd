# Cascade program fz_201_160: 2201 instructions; descriptor in fz_201_160.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 880400
expect_tohost 0
finish
