# Cascade program fz_201_104: 1471 instructions; descriptor in fz_201_104.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 588400
expect_tohost 0
finish
