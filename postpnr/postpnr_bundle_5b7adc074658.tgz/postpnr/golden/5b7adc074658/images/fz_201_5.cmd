# Cascade program fz_201_5: 1329 instructions; descriptor in fz_201_5.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 531600
expect_tohost 0
finish
