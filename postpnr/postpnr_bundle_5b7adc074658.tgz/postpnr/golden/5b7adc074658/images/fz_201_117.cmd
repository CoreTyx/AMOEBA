# Cascade program fz_201_117: 530 instructions; descriptor in fz_201_117.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 212000
expect_tohost 0
finish
