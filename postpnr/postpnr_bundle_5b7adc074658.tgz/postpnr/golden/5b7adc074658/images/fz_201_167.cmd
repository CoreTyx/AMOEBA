# Cascade program fz_201_167: 1549 instructions; descriptor in fz_201_167.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 619600
expect_tohost 0
finish
