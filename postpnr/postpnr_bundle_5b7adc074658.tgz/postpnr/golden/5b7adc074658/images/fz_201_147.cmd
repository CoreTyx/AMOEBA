# Cascade program fz_201_147: 778 instructions; descriptor in fz_201_147.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 311200
expect_tohost 0
finish
