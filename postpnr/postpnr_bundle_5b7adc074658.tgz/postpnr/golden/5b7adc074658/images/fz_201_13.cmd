# Cascade program fz_201_13: 1859 instructions; descriptor in fz_201_13.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 743600
expect_tohost 0
finish
