# Cascade program fz_201_285: 992 instructions; descriptor in fz_201_285.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 396800
expect_tohost 0
finish
