# Cascade program fz_201_166: 1013 instructions; descriptor in fz_201_166.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 405200
expect_tohost 0
finish
