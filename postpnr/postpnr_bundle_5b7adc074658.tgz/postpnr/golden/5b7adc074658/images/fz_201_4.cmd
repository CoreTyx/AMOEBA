# Cascade program fz_201_4: 2084 instructions; descriptor in fz_201_4.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 833600
expect_tohost 0
finish
