# Cascade program fz_201_73: 3253 instructions; descriptor in fz_201_73.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1301200
expect_tohost 0
finish
