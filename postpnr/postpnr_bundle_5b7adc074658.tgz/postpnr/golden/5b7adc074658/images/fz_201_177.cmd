# Cascade program fz_201_177: 263 instructions; descriptor in fz_201_177.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 200000
expect_tohost 0
finish
