# Cascade program fz_201_179: 1167 instructions; descriptor in fz_201_179.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 466800
expect_tohost 0
finish
