# Cascade program fz_201_169: 1231 instructions; descriptor in fz_201_169.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 492400
expect_tohost 0
finish
