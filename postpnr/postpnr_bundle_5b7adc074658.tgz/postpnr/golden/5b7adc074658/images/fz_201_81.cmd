# Cascade program fz_201_81: 922 instructions; descriptor in fz_201_81.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 368800
expect_tohost 0
finish
