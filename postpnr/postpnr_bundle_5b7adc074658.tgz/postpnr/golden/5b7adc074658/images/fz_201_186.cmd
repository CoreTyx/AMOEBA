# Cascade program fz_201_186: 1691 instructions; descriptor in fz_201_186.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 676400
expect_tohost 0
finish
