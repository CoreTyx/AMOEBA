# Cascade program fz_201_295: 1426 instructions; descriptor in fz_201_295.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 570400
expect_tohost 0
finish
