# Cascade program fz_201_280: 2246 instructions; descriptor in fz_201_280.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 898400
expect_tohost 0
finish
