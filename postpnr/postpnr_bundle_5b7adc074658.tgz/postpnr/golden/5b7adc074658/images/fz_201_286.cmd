# Cascade program fz_201_286: 2047 instructions; descriptor in fz_201_286.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 818800
expect_tohost 0
finish
