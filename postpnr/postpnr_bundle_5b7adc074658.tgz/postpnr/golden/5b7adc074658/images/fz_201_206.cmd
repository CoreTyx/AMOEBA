# Cascade program fz_201_206: 869 instructions; descriptor in fz_201_206.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 347600
expect_tohost 0
finish
