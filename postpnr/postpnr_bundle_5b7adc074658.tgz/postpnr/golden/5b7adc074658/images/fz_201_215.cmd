# Cascade program fz_201_215: 1058 instructions; descriptor in fz_201_215.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 423200
expect_tohost 0
finish
