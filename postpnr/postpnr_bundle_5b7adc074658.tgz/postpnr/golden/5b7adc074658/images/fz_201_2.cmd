# Cascade program fz_201_2: 1043 instructions; descriptor in fz_201_2.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 417200
expect_tohost 0
finish
