# Cascade program fz_201_55: 1310 instructions; descriptor in fz_201_55.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 524000
expect_tohost 0
finish
