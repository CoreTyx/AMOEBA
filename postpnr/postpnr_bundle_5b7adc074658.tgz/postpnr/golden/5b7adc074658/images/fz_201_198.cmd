# Cascade program fz_201_198: 1216 instructions; descriptor in fz_201_198.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 486400
expect_tohost 0
finish
