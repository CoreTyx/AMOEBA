# Cascade program fz_201_200: 1982 instructions; descriptor in fz_201_200.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 792800
expect_tohost 0
finish
