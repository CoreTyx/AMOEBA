# Cascade program fz_201_181: 1315 instructions; descriptor in fz_201_181.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 526000
expect_tohost 0
finish
