# Cascade program fz_201_3: 2524 instructions; descriptor in fz_201_3.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1009600
expect_tohost 0
finish
