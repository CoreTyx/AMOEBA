# Cascade program fz_201_41: 768 instructions; descriptor in fz_201_41.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 307200
expect_tohost 0
finish
