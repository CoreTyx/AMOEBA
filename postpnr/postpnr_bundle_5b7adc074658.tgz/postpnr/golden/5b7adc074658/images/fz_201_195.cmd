# Cascade program fz_201_195: 612 instructions; descriptor in fz_201_195.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 244800
expect_tohost 0
finish
