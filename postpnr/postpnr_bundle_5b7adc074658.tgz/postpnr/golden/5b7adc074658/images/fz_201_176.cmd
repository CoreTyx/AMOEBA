# Cascade program fz_201_176: 870 instructions; descriptor in fz_201_176.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 348000
expect_tohost 0
finish
