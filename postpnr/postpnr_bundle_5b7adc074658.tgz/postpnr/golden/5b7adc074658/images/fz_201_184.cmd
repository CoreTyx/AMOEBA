# Cascade program fz_201_184: 657 instructions; descriptor in fz_201_184.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 262800
expect_tohost 0
finish
