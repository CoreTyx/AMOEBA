# Cascade program fz_201_67: 1993 instructions; descriptor in fz_201_67.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 797200
expect_tohost 0
finish
