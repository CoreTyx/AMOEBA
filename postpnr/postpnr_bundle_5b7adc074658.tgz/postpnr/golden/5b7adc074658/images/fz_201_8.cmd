# Cascade program fz_201_8: 790 instructions; descriptor in fz_201_8.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 316000
expect_tohost 0
finish
