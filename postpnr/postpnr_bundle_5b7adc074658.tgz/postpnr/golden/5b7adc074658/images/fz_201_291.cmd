# Cascade program fz_201_291: 1212 instructions; descriptor in fz_201_291.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 484800
expect_tohost 0
finish
