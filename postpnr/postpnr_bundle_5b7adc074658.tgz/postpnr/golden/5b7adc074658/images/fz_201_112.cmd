# Cascade program fz_201_112: 2906 instructions; descriptor in fz_201_112.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1162400
expect_tohost 0
finish
