# Cascade program fz_201_187: 1749 instructions; descriptor in fz_201_187.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 699600
expect_tohost 0
finish
