# Cascade program fz_201_256: 1109 instructions; descriptor in fz_201_256.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 443600
expect_tohost 0
finish
