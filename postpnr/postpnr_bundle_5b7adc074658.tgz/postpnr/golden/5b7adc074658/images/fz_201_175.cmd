# Cascade program fz_201_175: 827 instructions; descriptor in fz_201_175.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 330800
expect_tohost 0
finish
