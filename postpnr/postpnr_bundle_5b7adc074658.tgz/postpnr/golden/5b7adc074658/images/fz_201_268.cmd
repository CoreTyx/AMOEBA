# Cascade program fz_201_268: 2471 instructions; descriptor in fz_201_268.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 988400
expect_tohost 0
finish
