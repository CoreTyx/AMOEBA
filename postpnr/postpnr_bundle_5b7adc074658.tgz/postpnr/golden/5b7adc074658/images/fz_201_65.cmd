# Cascade program fz_201_65: 1298 instructions; descriptor in fz_201_65.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 519200
expect_tohost 0
finish
