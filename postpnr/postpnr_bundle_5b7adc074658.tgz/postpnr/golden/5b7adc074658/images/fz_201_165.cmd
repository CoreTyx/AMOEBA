# Cascade program fz_201_165: 745 instructions; descriptor in fz_201_165.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 298000
expect_tohost 0
finish
