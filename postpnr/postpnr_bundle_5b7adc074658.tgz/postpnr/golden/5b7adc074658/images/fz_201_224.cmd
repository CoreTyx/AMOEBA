# Cascade program fz_201_224: 930 instructions; descriptor in fz_201_224.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 372000
expect_tohost 0
finish
