# Cascade program fz_201_130: 835 instructions; descriptor in fz_201_130.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 334000
expect_tohost 0
finish
