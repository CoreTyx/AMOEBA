# Cascade program fz_201_182: 3401 instructions; descriptor in fz_201_182.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1360400
expect_tohost 0
finish
