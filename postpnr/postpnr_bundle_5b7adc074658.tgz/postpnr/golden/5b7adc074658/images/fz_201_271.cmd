# Cascade program fz_201_271: 1796 instructions; descriptor in fz_201_271.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 718400
expect_tohost 0
finish
