# Cascade program fz_201_123: 641 instructions; descriptor in fz_201_123.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 256400
expect_tohost 0
finish
