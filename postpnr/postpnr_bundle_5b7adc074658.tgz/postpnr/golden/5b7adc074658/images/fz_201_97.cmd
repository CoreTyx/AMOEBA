# Cascade program fz_201_97: 682 instructions; descriptor in fz_201_97.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 272800
expect_tohost 0
finish
