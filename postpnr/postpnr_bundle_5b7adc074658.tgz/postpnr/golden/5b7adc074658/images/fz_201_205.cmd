# Cascade program fz_201_205: 1104 instructions; descriptor in fz_201_205.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 441600
expect_tohost 0
finish
