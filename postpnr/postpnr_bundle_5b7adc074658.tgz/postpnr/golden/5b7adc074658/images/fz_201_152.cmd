# Cascade program fz_201_152: 893 instructions; descriptor in fz_201_152.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 357200
expect_tohost 0
finish
