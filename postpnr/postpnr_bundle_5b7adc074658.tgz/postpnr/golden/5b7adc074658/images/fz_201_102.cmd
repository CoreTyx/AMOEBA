# Cascade program fz_201_102: 1028 instructions; descriptor in fz_201_102.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 411200
expect_tohost 0
finish
