# Cascade program fz_201_183: 1423 instructions; descriptor in fz_201_183.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 569200
expect_tohost 0
finish
