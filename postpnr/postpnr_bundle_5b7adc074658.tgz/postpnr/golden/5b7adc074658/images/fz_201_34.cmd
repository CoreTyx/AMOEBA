# Cascade program fz_201_34: 979 instructions; descriptor in fz_201_34.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 391600
expect_tohost 0
finish
