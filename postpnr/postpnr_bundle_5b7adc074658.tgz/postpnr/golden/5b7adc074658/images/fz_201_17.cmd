# Cascade program fz_201_17: 1168 instructions; descriptor in fz_201_17.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 467200
expect_tohost 0
finish
