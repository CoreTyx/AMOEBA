# Cascade program fz_201_232: 598 instructions; descriptor in fz_201_232.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 239200
expect_tohost 0
finish
