# Cascade program fz_201_109: 1821 instructions; descriptor in fz_201_109.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 728400
expect_tohost 0
finish
