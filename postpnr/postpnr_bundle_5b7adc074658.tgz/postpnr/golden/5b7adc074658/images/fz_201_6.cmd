# Cascade program fz_201_6: 1860 instructions; descriptor in fz_201_6.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 744000
expect_tohost 0
finish
