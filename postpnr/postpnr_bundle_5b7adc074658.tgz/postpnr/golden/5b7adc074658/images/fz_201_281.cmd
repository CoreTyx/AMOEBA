# Cascade program fz_201_281: 1461 instructions; descriptor in fz_201_281.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 584400
expect_tohost 0
finish
