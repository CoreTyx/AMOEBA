# Cascade program fz_201_19: 624 instructions; descriptor in fz_201_19.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 249600
expect_tohost 0
finish
