# Cascade program fz_201_159: 1039 instructions; descriptor in fz_201_159.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 415600
expect_tohost 0
finish
