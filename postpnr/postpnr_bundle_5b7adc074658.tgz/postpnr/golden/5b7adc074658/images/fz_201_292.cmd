# Cascade program fz_201_292: 1643 instructions; descriptor in fz_201_292.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 657200
expect_tohost 0
finish
