# Cascade program fz_201_185: 514 instructions; descriptor in fz_201_185.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 205600
expect_tohost 0
finish
