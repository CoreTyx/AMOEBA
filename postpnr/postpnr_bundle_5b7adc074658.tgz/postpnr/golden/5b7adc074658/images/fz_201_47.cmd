# Cascade program fz_201_47: 1285 instructions; descriptor in fz_201_47.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 514000
expect_tohost 0
finish
