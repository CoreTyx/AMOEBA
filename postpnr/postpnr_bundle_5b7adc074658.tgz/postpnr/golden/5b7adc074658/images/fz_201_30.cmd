# Cascade program fz_201_30: 922 instructions; descriptor in fz_201_30.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 368800
expect_tohost 0
finish
