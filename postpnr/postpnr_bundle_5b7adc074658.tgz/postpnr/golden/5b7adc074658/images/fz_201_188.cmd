# Cascade program fz_201_188: 783 instructions; descriptor in fz_201_188.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 313200
expect_tohost 0
finish
