# Cascade program fz_201_93: 900 instructions; descriptor in fz_201_93.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 360000
expect_tohost 0
finish
