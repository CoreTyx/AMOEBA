# Cascade program fz_201_83: 4603 instructions; descriptor in fz_201_83.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1841200
expect_tohost 0
finish
