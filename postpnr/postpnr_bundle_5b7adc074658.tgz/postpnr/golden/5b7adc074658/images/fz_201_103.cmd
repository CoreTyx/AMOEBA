# Cascade program fz_201_103: 1281 instructions; descriptor in fz_201_103.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 512400
expect_tohost 0
finish
