# Cascade program fz_201_72: 1364 instructions; descriptor in fz_201_72.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 545600
expect_tohost 0
finish
