# Cascade program fz_201_88: 803 instructions; descriptor in fz_201_88.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 321200
expect_tohost 0
finish
