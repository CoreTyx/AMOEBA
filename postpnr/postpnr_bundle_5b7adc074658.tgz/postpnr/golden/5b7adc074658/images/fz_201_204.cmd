# Cascade program fz_201_204: 839 instructions; descriptor in fz_201_204.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 335600
expect_tohost 0
finish
