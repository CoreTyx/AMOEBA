# Cascade program fz_201_132: 1240 instructions; descriptor in fz_201_132.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 496000
expect_tohost 0
finish
