# Cascade program fz_201_12: 1103 instructions; descriptor in fz_201_12.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 441200
expect_tohost 0
finish
