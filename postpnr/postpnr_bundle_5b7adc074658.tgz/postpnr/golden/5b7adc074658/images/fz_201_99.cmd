# Cascade program fz_201_99: 833 instructions; descriptor in fz_201_99.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 333200
expect_tohost 0
finish
