# Cascade program fz_201_78: 1296 instructions; descriptor in fz_201_78.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 518400
expect_tohost 0
finish
