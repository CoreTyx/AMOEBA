# Cascade program fz_201_96: 971 instructions; descriptor in fz_201_96.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 388400
expect_tohost 0
finish
