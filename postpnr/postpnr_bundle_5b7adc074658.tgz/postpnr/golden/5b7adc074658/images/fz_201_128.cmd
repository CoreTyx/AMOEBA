# Cascade program fz_201_128: 1588 instructions; descriptor in fz_201_128.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 635200
expect_tohost 0
finish
