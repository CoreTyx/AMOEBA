# Cascade program fz_201_245: 1454 instructions; descriptor in fz_201_245.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 581600
expect_tohost 0
finish
