# Cascade program fz_201_213: 1050 instructions; descriptor in fz_201_213.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 420000
expect_tohost 0
finish
