# Cascade program fz_201_202: 2332 instructions; descriptor in fz_201_202.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 932800
expect_tohost 0
finish
