# Cascade program fz_201_264: 1274 instructions; descriptor in fz_201_264.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 509600
expect_tohost 0
finish
