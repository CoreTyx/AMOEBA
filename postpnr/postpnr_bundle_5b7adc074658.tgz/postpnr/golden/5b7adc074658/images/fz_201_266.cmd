# Cascade program fz_201_266: 943 instructions; descriptor in fz_201_266.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 377200
expect_tohost 0
finish
