# Cascade program fz_201_118: 1091 instructions; descriptor in fz_201_118.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 436400
expect_tohost 0
finish
