# Cascade program fz_201_44: 1056 instructions; descriptor in fz_201_44.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 422400
expect_tohost 0
finish
