# Cascade program fz_201_76: 2232 instructions; descriptor in fz_201_76.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 892800
expect_tohost 0
finish
