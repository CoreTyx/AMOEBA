# Cascade program fz_201_59: 1378 instructions; descriptor in fz_201_59.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 551200
expect_tohost 0
finish
