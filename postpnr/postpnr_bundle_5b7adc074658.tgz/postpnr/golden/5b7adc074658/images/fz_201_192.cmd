# Cascade program fz_201_192: 1040 instructions; descriptor in fz_201_192.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 416000
expect_tohost 0
finish
