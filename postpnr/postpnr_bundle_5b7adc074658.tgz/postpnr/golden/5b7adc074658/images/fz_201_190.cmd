# Cascade program fz_201_190: 1252 instructions; descriptor in fz_201_190.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 500800
expect_tohost 0
finish
