# Cascade program fz_201_238: 1412 instructions; descriptor in fz_201_238.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 564800
expect_tohost 0
finish
