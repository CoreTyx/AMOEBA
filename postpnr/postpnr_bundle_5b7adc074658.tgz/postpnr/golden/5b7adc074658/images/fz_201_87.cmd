# Cascade program fz_201_87: 650 instructions; descriptor in fz_201_87.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 260000
expect_tohost 0
finish
