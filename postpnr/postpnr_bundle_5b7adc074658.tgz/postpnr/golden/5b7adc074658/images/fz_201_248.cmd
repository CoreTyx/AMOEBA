# Cascade program fz_201_248: 785 instructions; descriptor in fz_201_248.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 314000
expect_tohost 0
finish
