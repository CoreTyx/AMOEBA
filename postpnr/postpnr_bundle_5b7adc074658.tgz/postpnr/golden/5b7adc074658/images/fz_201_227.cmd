# Cascade program fz_201_227: 1551 instructions; descriptor in fz_201_227.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 620400
expect_tohost 0
finish
