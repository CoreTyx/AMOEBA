# Cascade program fz_201_269: 1044 instructions; descriptor in fz_201_269.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 417600
expect_tohost 0
finish
