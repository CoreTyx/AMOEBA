# Cascade program fz_201_196: 799 instructions; descriptor in fz_201_196.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 319600
expect_tohost 0
finish
