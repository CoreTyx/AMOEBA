# Cascade program fz_201_48: 511 instructions; descriptor in fz_201_48.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 204400
expect_tohost 0
finish
