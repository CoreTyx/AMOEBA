# Cascade program fz_201_155: 1177 instructions; descriptor in fz_201_155.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 470800
expect_tohost 0
finish
