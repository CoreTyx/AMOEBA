# Cascade program fz_201_89: 1581 instructions; descriptor in fz_201_89.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 632400
expect_tohost 0
finish
