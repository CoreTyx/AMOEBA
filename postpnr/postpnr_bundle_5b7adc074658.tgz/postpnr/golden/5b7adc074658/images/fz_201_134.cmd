# Cascade program fz_201_134: 2576 instructions; descriptor in fz_201_134.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1030400
expect_tohost 0
finish
