# Cascade program fz_201_46: 1955 instructions; descriptor in fz_201_46.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 782000
expect_tohost 0
finish
