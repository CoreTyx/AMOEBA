# Cascade program fz_201_105: 706 instructions; descriptor in fz_201_105.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 282400
expect_tohost 0
finish
