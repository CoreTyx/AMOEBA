# Cascade program fz_201_150: 1510 instructions; descriptor in fz_201_150.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 604000
expect_tohost 0
finish
