# Cascade program fz_201_287: 1334 instructions; descriptor in fz_201_287.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 533600
expect_tohost 0
finish
