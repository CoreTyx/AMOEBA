# Cascade program fz_201_161: 631 instructions; descriptor in fz_201_161.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 252400
expect_tohost 0
finish
