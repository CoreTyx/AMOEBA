# Cascade program fz_201_53: 1389 instructions; descriptor in fz_201_53.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 555600
expect_tohost 0
finish
