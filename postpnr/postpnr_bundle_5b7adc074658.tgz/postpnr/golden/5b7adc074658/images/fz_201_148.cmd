# Cascade program fz_201_148: 662 instructions; descriptor in fz_201_148.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 264800
expect_tohost 0
finish
