# Cascade program fz_201_277: 2112 instructions; descriptor in fz_201_277.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 844800
expect_tohost 0
finish
