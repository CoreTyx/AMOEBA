# Cascade program fz_201_258: 1557 instructions; descriptor in fz_201_258.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 622800
expect_tohost 0
finish
