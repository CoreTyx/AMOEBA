# Cascade program fz_201_193: 689 instructions; descriptor in fz_201_193.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 275600
expect_tohost 0
finish
