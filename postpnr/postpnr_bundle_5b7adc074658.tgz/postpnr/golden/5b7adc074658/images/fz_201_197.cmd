# Cascade program fz_201_197: 1365 instructions; descriptor in fz_201_197.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 546000
expect_tohost 0
finish
