# Cascade program fz_201_21: 1032 instructions; descriptor in fz_201_21.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 412800
expect_tohost 0
finish
