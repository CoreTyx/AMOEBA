# Cascade program fz_201_265: 842 instructions; descriptor in fz_201_265.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 336800
expect_tohost 0
finish
