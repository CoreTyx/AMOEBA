# Cascade program fz_201_282: 1320 instructions; descriptor in fz_201_282.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 528000
expect_tohost 0
finish
