# Cascade program fz_201_222: 1711 instructions; descriptor in fz_201_222.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 684400
expect_tohost 0
finish
