# Cascade program fz_201_214: 2009 instructions; descriptor in fz_201_214.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 803600
expect_tohost 0
finish
