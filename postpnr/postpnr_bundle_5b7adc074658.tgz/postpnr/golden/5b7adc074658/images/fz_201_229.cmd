# Cascade program fz_201_229: 1209 instructions; descriptor in fz_201_229.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 483600
expect_tohost 0
finish
