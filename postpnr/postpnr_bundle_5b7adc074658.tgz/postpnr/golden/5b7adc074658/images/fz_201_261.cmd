# Cascade program fz_201_261: 1243 instructions; descriptor in fz_201_261.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 497200
expect_tohost 0
finish
