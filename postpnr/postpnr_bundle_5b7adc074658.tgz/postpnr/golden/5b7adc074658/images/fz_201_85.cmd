# Cascade program fz_201_85: 720 instructions; descriptor in fz_201_85.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 288000
expect_tohost 0
finish
