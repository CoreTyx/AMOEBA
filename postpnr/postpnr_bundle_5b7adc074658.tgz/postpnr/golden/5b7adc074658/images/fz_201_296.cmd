# Cascade program fz_201_296: 1222 instructions; descriptor in fz_201_296.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 488800
expect_tohost 0
finish
