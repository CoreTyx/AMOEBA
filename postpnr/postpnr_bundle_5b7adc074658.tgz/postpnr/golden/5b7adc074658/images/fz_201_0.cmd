# Cascade program fz_201_0: 1096 instructions; descriptor in fz_201_0.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 438400
expect_tohost 0
finish
