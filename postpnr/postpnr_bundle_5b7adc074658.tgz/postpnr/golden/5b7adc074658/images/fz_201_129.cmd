# Cascade program fz_201_129: 1002 instructions; descriptor in fz_201_129.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 400800
expect_tohost 0
finish
