# Cascade program fz_201_289: 1491 instructions; descriptor in fz_201_289.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 596400
expect_tohost 0
finish
