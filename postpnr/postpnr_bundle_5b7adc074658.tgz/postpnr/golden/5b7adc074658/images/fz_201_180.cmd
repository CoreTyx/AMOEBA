# Cascade program fz_201_180: 1637 instructions; descriptor in fz_201_180.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 654800
expect_tohost 0
finish
