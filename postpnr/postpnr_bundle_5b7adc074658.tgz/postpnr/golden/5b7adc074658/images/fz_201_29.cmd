# Cascade program fz_201_29: 1663 instructions; descriptor in fz_201_29.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 665200
expect_tohost 0
finish
