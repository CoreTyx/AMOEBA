# Cascade program fz_201_284: 642 instructions; descriptor in fz_201_284.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 256800
expect_tohost 0
finish
