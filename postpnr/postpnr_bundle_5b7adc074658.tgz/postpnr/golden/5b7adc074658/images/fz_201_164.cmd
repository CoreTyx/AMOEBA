# Cascade program fz_201_164: 663 instructions; descriptor in fz_201_164.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 265200
expect_tohost 0
finish
