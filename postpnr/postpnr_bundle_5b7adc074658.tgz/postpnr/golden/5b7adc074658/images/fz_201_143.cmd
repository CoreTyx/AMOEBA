# Cascade program fz_201_143: 2121 instructions; descriptor in fz_201_143.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 848400
expect_tohost 0
finish
