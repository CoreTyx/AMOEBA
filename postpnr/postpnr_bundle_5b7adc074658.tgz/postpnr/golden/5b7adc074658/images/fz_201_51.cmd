# Cascade program fz_201_51: 1084 instructions; descriptor in fz_201_51.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 433600
expect_tohost 0
finish
