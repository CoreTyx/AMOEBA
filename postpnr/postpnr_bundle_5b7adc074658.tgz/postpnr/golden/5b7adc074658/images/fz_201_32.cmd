# Cascade program fz_201_32: 930 instructions; descriptor in fz_201_32.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 372000
expect_tohost 0
finish
