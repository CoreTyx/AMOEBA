# Cascade program fz_201_234: 1284 instructions; descriptor in fz_201_234.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 513600
expect_tohost 0
finish
