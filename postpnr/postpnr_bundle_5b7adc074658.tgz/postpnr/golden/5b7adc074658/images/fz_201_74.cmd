# Cascade program fz_201_74: 1368 instructions; descriptor in fz_201_74.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 547200
expect_tohost 0
finish
