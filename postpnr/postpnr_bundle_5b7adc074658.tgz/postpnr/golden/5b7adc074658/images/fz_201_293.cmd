# Cascade program fz_201_293: 678 instructions; descriptor in fz_201_293.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 271200
expect_tohost 0
finish
