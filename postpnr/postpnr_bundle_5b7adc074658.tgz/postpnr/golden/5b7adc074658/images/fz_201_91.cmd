# Cascade program fz_201_91: 975 instructions; descriptor in fz_201_91.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 390000
expect_tohost 0
finish
