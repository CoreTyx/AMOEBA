# Cascade program fz_201_40: 934 instructions; descriptor in fz_201_40.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 373600
expect_tohost 0
finish
