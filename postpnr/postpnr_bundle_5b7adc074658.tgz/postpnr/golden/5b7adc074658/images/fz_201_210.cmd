# Cascade program fz_201_210: 1088 instructions; descriptor in fz_201_210.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 435200
expect_tohost 0
finish
