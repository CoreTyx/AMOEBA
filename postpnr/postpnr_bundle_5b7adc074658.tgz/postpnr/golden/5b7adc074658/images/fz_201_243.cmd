# Cascade program fz_201_243: 1118 instructions; descriptor in fz_201_243.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 447200
expect_tohost 0
finish
