# Cascade program fz_201_94: 876 instructions; descriptor in fz_201_94.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 350400
expect_tohost 0
finish
