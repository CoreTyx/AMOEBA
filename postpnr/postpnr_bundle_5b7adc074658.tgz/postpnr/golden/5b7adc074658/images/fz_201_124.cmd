# Cascade program fz_201_124: 999 instructions; descriptor in fz_201_124.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 399600
expect_tohost 0
finish
