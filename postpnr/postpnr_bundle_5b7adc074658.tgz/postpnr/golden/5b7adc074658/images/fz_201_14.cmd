# Cascade program fz_201_14: 1827 instructions; descriptor in fz_201_14.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 730800
expect_tohost 0
finish
