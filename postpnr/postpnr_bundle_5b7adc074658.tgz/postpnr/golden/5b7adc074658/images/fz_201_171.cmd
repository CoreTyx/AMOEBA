# Cascade program fz_201_171: 3611 instructions; descriptor in fz_201_171.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1444400
expect_tohost 0
finish
