# Cascade program fz_201_49: 1047 instructions; descriptor in fz_201_49.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 418800
expect_tohost 0
finish
