# Cascade program fz_201_174: 1020 instructions; descriptor in fz_201_174.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 408000
expect_tohost 0
finish
