# Cascade program fz_201_145: 1907 instructions; descriptor in fz_201_145.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 762800
expect_tohost 0
finish
