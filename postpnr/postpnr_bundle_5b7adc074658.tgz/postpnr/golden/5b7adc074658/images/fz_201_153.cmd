# Cascade program fz_201_153: 2508 instructions; descriptor in fz_201_153.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1003200
expect_tohost 0
finish
