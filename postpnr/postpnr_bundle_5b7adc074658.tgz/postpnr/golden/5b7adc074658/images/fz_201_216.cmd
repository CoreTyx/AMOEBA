# Cascade program fz_201_216: 1160 instructions; descriptor in fz_201_216.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 464000
expect_tohost 0
finish
