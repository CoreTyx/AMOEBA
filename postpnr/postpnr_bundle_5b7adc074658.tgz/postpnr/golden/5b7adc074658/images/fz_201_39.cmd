# Cascade program fz_201_39: 1237 instructions; descriptor in fz_201_39.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 494800
expect_tohost 0
finish
