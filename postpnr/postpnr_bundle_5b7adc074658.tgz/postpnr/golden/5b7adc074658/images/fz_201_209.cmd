# Cascade program fz_201_209: 1273 instructions; descriptor in fz_201_209.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 509200
expect_tohost 0
finish
