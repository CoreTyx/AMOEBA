# Cascade program fz_201_60: 836 instructions; descriptor in fz_201_60.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 334400
expect_tohost 0
finish
