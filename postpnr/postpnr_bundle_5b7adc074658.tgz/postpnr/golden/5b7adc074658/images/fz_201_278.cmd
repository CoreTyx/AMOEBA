# Cascade program fz_201_278: 894 instructions; descriptor in fz_201_278.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 357600
expect_tohost 0
finish
