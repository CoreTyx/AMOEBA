# Cascade program fz_201_42: 2049 instructions; descriptor in fz_201_42.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 819600
expect_tohost 0
finish
