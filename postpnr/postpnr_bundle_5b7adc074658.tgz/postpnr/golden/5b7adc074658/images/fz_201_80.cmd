# Cascade program fz_201_80: 688 instructions; descriptor in fz_201_80.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 275200
expect_tohost 0
finish
