# Cascade program fz_201_45: 786 instructions; descriptor in fz_201_45.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 314400
expect_tohost 0
finish
