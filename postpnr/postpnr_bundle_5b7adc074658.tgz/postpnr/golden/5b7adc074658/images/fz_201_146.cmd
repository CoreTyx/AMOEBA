# Cascade program fz_201_146: 1926 instructions; descriptor in fz_201_146.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 770400
expect_tohost 0
finish
