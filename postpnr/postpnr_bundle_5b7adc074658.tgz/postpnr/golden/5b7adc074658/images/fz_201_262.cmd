# Cascade program fz_201_262: 1608 instructions; descriptor in fz_201_262.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 643200
expect_tohost 0
finish
