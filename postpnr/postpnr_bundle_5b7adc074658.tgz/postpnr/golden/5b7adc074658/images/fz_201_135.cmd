# Cascade program fz_201_135: 698 instructions; descriptor in fz_201_135.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 279200
expect_tohost 0
finish
