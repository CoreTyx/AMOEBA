# Cascade program fz_201_163: 1803 instructions; descriptor in fz_201_163.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 721200
expect_tohost 0
finish
