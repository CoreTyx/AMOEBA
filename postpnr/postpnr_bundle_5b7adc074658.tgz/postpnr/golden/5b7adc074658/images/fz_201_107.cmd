# Cascade program fz_201_107: 1239 instructions; descriptor in fz_201_107.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 495600
expect_tohost 0
finish
