# Cascade program fz_201_56: 821 instructions; descriptor in fz_201_56.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 328400
expect_tohost 0
finish
