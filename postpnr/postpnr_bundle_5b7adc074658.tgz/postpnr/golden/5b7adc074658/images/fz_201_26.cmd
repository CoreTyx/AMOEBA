# Cascade program fz_201_26: 620 instructions; descriptor in fz_201_26.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 248000
expect_tohost 0
finish
