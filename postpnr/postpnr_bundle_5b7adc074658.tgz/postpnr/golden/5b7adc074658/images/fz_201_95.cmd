# Cascade program fz_201_95: 1703 instructions; descriptor in fz_201_95.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 681200
expect_tohost 0
finish
