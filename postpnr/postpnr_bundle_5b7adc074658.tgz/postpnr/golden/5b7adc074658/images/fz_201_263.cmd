# Cascade program fz_201_263: 1483 instructions; descriptor in fz_201_263.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 593200
expect_tohost 0
finish
