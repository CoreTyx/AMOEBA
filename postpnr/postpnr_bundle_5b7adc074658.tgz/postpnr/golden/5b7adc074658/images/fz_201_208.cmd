# Cascade program fz_201_208: 1163 instructions; descriptor in fz_201_208.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 465200
expect_tohost 0
finish
