# Cascade program fz_201_218: 1278 instructions; descriptor in fz_201_218.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 511200
expect_tohost 0
finish
