# Cascade program fz_201_69: 1714 instructions; descriptor in fz_201_69.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 685600
expect_tohost 0
finish
