# Cascade program fz_201_244: 852 instructions; descriptor in fz_201_244.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 340800
expect_tohost 0
finish
