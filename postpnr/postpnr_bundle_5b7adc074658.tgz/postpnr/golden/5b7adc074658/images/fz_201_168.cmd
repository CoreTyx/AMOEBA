# Cascade program fz_201_168: 1960 instructions; descriptor in fz_201_168.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 784000
expect_tohost 0
finish
