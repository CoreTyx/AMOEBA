# Cascade program fz_201_225: 1070 instructions; descriptor in fz_201_225.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 428000
expect_tohost 0
finish
