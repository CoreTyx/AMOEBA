# Cascade program fz_201_113: 1286 instructions; descriptor in fz_201_113.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 514400
expect_tohost 0
finish
