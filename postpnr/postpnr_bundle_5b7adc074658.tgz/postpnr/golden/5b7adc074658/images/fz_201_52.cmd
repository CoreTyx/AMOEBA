# Cascade program fz_201_52: 901 instructions; descriptor in fz_201_52.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 360400
expect_tohost 0
finish
