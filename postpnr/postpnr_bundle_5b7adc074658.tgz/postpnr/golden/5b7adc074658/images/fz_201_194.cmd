# Cascade program fz_201_194: 1154 instructions; descriptor in fz_201_194.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 461600
expect_tohost 0
finish
