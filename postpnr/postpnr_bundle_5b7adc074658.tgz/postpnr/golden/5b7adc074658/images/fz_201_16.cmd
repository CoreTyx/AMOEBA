# Cascade program fz_201_16: 1418 instructions; descriptor in fz_201_16.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 567200
expect_tohost 0
finish
