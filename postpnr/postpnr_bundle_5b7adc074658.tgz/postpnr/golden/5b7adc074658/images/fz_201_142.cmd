# Cascade program fz_201_142: 2093 instructions; descriptor in fz_201_142.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 837200
expect_tohost 0
finish
