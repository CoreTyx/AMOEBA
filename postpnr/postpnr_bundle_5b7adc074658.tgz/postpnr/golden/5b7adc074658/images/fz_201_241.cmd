# Cascade program fz_201_241: 907 instructions; descriptor in fz_201_241.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 362800
expect_tohost 0
finish
