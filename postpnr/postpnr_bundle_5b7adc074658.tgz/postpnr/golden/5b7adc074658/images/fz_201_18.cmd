# Cascade program fz_201_18: 532 instructions; descriptor in fz_201_18.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 212800
expect_tohost 0
finish
