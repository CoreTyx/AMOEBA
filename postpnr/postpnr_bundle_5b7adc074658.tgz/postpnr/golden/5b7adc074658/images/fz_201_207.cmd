# Cascade program fz_201_207: 740 instructions; descriptor in fz_201_207.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 296000
expect_tohost 0
finish
