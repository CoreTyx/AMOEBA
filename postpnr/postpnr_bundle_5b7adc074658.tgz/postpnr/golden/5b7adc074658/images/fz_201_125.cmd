# Cascade program fz_201_125: 1062 instructions; descriptor in fz_201_125.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 424800
expect_tohost 0
finish
