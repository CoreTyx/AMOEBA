# Cascade program fz_201_151: 507 instructions; descriptor in fz_201_151.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 202800
expect_tohost 0
finish
