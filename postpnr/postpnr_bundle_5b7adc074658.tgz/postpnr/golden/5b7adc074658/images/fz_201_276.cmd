# Cascade program fz_201_276: 2615 instructions; descriptor in fz_201_276.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1046000
expect_tohost 0
finish
