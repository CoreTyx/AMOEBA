# Cascade program fz_201_68: 4286 instructions; descriptor in fz_201_68.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1714400
expect_tohost 0
finish
