# Cascade program fz_201_120: 1162 instructions; descriptor in fz_201_120.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 464800
expect_tohost 0
finish
