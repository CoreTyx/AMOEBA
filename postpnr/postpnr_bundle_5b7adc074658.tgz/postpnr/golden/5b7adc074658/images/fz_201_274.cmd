# Cascade program fz_201_274: 1264 instructions; descriptor in fz_201_274.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 505600
expect_tohost 0
finish
