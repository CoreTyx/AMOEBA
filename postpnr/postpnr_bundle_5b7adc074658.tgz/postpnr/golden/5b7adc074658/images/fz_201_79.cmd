# Cascade program fz_201_79: 824 instructions; descriptor in fz_201_79.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 329600
expect_tohost 0
finish
