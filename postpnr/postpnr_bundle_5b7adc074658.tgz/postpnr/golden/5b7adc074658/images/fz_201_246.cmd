# Cascade program fz_201_246: 3094 instructions; descriptor in fz_201_246.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 1237600
expect_tohost 0
finish
