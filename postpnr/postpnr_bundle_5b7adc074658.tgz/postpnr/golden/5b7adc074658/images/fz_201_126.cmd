# Cascade program fz_201_126: 2015 instructions; descriptor in fz_201_126.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 806000
expect_tohost 0
finish
