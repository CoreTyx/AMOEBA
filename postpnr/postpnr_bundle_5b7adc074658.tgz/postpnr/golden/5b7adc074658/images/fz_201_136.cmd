# Cascade program fz_201_136: 1299 instructions; descriptor in fz_201_136.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 519600
expect_tohost 0
finish
