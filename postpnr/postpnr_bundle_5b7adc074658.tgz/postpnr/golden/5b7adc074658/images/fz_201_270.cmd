# Cascade program fz_201_270: 2411 instructions; descriptor in fz_201_270.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 964400
expect_tohost 0
finish
