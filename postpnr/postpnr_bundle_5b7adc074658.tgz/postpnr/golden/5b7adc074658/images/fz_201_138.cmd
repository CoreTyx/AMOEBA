# Cascade program fz_201_138: 1852 instructions; descriptor in fz_201_138.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 740800
expect_tohost 0
finish
