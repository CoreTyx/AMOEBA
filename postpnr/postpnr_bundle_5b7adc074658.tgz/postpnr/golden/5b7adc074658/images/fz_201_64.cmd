# Cascade program fz_201_64: 912 instructions; descriptor in fz_201_64.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 364800
expect_tohost 0
finish
