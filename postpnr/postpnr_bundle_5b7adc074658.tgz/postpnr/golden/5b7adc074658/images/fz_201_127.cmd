# Cascade program fz_201_127: 1468 instructions; descriptor in fz_201_127.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 587200
expect_tohost 0
finish
