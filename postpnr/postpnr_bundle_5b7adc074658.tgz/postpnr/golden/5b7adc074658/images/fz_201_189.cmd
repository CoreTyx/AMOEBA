# Cascade program fz_201_189: 1905 instructions; descriptor in fz_201_189.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 762000
expect_tohost 0
finish
