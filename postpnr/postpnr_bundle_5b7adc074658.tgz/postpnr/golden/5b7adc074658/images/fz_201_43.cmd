# Cascade program fz_201_43: 1601 instructions; descriptor in fz_201_43.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 640400
expect_tohost 0
finish
