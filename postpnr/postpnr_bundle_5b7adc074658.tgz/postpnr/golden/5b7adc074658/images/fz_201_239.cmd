# Cascade program fz_201_239: 2166 instructions; descriptor in fz_201_239.txt
mem_policy zero
load_lst $MEM
reset 16
run_until_tohost 866400
expect_tohost 0
finish
